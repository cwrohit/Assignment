package mypackage;
// we can read only (only getter method)
public class Read_Encap {
	private String name="Rohit";
	//getting the name
	public String getName() {
		return name;	
	}
	public static void main(String[] args) {
		Read_Encap obj = new Read_Encap();
		System.out.println(obj.name);
	}

}
