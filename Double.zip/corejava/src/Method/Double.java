package Method;
import java.util.Scanner;
public class Double {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("first input");
		double d1 = sc.nextDouble();
		System.out.println("second input");
		double d2= sc.nextInt();
		System.out.println(d1 > 10 && d1 < 15 && d2 > 10 & d2 < 15);
		
	}
}
