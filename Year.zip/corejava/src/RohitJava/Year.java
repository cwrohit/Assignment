package RohitJava;
import java.util.Scanner;
public class Year {
	public static void main(String[] args) {
		//Todo Auto generated method stub
		// here a year is in the form of the minute
		
		Scanner input = new Scanner(System.in);
		System.out.print("Input the time"+"of minutes");
		long year1= 60*24*365;
		long min = input.nextLong();
		//here the min will convert in the year
		long year = (min/year1);
		// minute will convert in the day;
		int days = (int)(min/60/24)%365;
		System.out.println("years  :"+ year +" days:"+days);
		
	}

}
