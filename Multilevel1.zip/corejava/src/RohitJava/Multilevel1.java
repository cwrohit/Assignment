package RohitJava;

class Multilevel {
	String name;
}
class Do extends Multilevel{
	int id;
}
class do1 extends Do{
	String city;
	
	void get (String a,int b,String c) {
		this.name=a;
		this.id=b;
		this.city=c;
		
	}
	void show() {
		System.out.println("name is:"+name+"\n"+"id is:"+id+"\n"+"city is:"+city);
	}
}
public class Multilevel1{
	public static void main(String[] args) {
		do1 d= new do1();
		d.get("ROhit", 100, "Haryana");
		d.show();
		
	}
}




