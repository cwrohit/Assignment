package RohitJava;

 class Single5 {  //parent  class
	 int a,b;
	 void show()
	 {
		 System.out.println("sum is:"+(a+b));
	 }
}
 public class Single2 extends Single5
 {
	 void get(int a ,int b) {
		 this.a=a;
		 this.b=b;		 
	 }
	 public static void main(String[] args) {
		Single2 child=new Single2();
		child.get(8,2);
		child.show();
		
		
	 
	 
	 }
	 
		 
		 
	 }

