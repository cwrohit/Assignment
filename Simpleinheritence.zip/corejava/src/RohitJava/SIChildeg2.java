package RohitJava;

class SIparenteg2 {//parent class
	int salary = 45000; //parent class salary
	
}
public class SIChildeg2 extends SIparenteg2{
	int bonus =1500;
	int annualsal = salary+bonus;
	public static void main(String[]abc){
		SIChildeg2 anyname = new SIChildeg2();
		System.out.println("Salary is :"+anyname.salary);
		System.out.println("annual salary is:"+anyname.annualsal);
		
		
	}
	

}
