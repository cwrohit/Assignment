package mypackage;

public class Write_encap {
	private String name; 
	public void Setname() {
		this.name= name;
	}
	public static void main(String[] args) {
		Write_encap obj = new Write_encap();
		obj.Setname();
		//we can not get the name there is no get method
		System.out.println(obj.name);
	}
	

}
