package RohitJava;

public class Expression {
public static void main(String[] args) {
	int i = (101+0)/3;
	double d= 3.0e-6*10000000.1;
	Boolean b1= true&&true;
	Boolean b2= false&&true;
	Boolean b3= (false&&false) || (true&&true);
	Boolean b4= (false||false) && (true&&true);
	System.out.println("(101+0)/3 =>" +i);
	System.out.println(" 3.0e-6*10000000.1 ->" +d);
	System.out.println("  true&&true->" +b1);
	System.out.println(" false&&true->" +b2);
	System.out.println(" (false&&false) || (true&&true)->" +b3);
	System.out.println("(false||false) && (true&&true)->" +b4);
	
}
}
