package mypackage;

public class Main1 {
	public static void main(String[] args) {
		Movie M = new Movie();
		M.setMoviename("Pathan");
		M.setMoviestarttime("10am");
		M.setMovieendtime("12:45pm");
		M.setMovieprice(200);
		
		System.out.println("movie name is:"+M.getMoviename());
		System.out.println("movie starting time is:"+M.getMoviestarttime());
		System.out.println("movie end time is:"+M.getMovieendtime());
		System.out.println("movie ticket price is:"+M.getMovieprice());
	}
}
