package RohitJava;
class Case{
	int salary = 45000;
	
}
class Bca extends Case{
	int bonus = 1000;
}

class Bca2 extends Bca{
	int a= 2000;
	void show()
	{
	System.out.println("net salary is"+"case salary");
		
	}
}
public class Multilevel_2 {

}
