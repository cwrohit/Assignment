package mypackage;

public class Encapsulated_ex {
	public static void main(String[] args) {
		Person1 p = new Person1();//creating the object of encapsulation
		p.setName("Rohit"); //setting value of name
		p.setAge(20);//setting value of age
		//getting value of the name and age
		System.out.println("name is:"+p.getName());
		System.out.println("Age is:"+p.getAge());
	}

}
