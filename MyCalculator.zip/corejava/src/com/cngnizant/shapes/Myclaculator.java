package com.cngnizant.shapes;
import java.util.Scanner;
class AdvancedArithmetic{
	void divisor_Sum(int n) {
		Scanner sc = new Scanner(System.in);
		System.out.println("ENter the number");
		int num = sc.nextInt();
		if(num<1000);
		int sum=0;
		for (int i=1; 1<num;i++) {
			if(num%i==0)
			{
				System.out.println(" "+i);
				System.out.println("now sum is:");
				System.out.println(sum=sum+i);		
			}
		}		
	}
}

 class Myclaculator extends AdvancedArithmetic{
	 public static void main(String[] args) {
		 AdvancedArithmetic sc = new AdvancedArithmetic();
		 sc.divisor_Sum(0);
				 
				 
				 
				 
	}

	
	
	
}
