package mypackage;

public class Movie {
	private String moviename;
	private String moviestarttime;
	private String movieendtime;
	private float movieprice;
	public String getMoviename() {
		return moviename;
	}
	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}
	public String getMoviestarttime() {
		return moviestarttime;
	}
	public void setMoviestarttime(String moviestarttime) {
		this.moviestarttime = moviestarttime;
	}
	public String getMovieendtime() {
		return movieendtime;
	}
	public void setMovieendtime(String movieendtime) {
		this.movieendtime = movieendtime;
	}
	public float getMovieprice() {
		return movieprice;
	}
	public void setMovieprice(float movieprice) {
		this.movieprice = movieprice;
	}
	
		
	}
	