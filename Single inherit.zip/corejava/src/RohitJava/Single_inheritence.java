package RohitJava;

public class Single_inheritence {//parent class
	void show()//parent class user defined method
	{
		System.out.println("Shoe the detail");
		
	}
	class SIChild extends Single_inheritence//child class
	{
		void display()//child class user defined method	
		{
			System.out.println("Display the result");	
		}
}
	public class Si{
		public static void main(String[] args) {
		Single_inheritence  child = new Single_inheritence ();
		//child.display();
		child.show();
		
		}
	}
 
}
